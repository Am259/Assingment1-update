using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

public class LeftNavigationViewComponent : ViewComponent
{
    public IViewComponentResult Invoke()
    {
        var links = new List<NavigationLink>
        {
            new NavigationLink("Home", "/"),
            new NavigationLink("Employees", "/Employee"),
            new NavigationLink("Privacy", "/Privacy"),
        };

        return View(links);
    }
}

public class NavigationLink
{
    public string Text { get; set; }
    public string Url { get; set; }

    public NavigationLink(string text, string url)
    {
        Text = text;
        Url = url;
    }
}