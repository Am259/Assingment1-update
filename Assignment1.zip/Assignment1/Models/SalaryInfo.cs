    using System.ComponentModel.DataAnnotations;
namespace MvcAssignment1.Models
{
public class SalaryInfo
{
    public int Id { get; set; }
    public decimal Net { get; set; }
    public decimal Gross { get; set; }

    public int EmployeeId { get; set; }
    public required Employee Employee { get; set; }
}
}