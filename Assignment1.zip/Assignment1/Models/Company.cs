    using System.ComponentModel.DataAnnotations;
namespace MvcAssignment1.Models
{
public class Company
{
    public Company()
    {
        Employees = new List<Employee>(); 
    }

    public int Id { get; set; }

    [Required]
    [MinLength(3)]
    [MaxLength(100)]
    public string Name { get; set; }

    [Required]
    [StringLength(5, MinimumLength = 5, ErrorMessage = "Zipcode must be exactly 5 characters.")]
    [RegularExpression("^[0-9]*$", ErrorMessage = "Zipcode can contain only digits.")]
    public string Zipcode { get; set; }

    [MaxLength(50)]
    public string City { get; set; }

    [MaxLength(60)]
    public string Country { get; set; }

    public List<Employee> Employees { get; set; }
}
}
