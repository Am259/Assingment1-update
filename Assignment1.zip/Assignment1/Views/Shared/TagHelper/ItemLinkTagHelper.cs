using Microsoft.AspNetCore.Razor.TagHelpers;

namespace MvcAssignment1.Models.TagHelpers
{
    public class ItemLinkTagHelper : TagHelper
    {
        public required string ControllerName { get; set; }
        public required string ActionName { get; set; }
        public int ItemId { get; set; }
        public required string DisplayText { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            // Generate the HTML for the link
            var link = $"/{ControllerName}/{ActionName}/{ItemId}";

            output.TagName = "a";
            output.Attributes.SetAttribute("href", link);
            output.Content.SetContent(DisplayText);
        }
    }
}
