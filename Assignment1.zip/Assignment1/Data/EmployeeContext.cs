﻿using Microsoft.EntityFrameworkCore;
using MvcAssignment1.Models;
public class EmployeeContext : DbContext
{
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Company> Companies { get; set; }
    public DbSet<SalaryInfo> SalaryInfos { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Company>().HasData(
            new Company { Id = 1, Name = "Company1", Zipcode = "12345", City = "City1", Country = "Country1" },
            new Company { Id = 2, Name = "Company2", Zipcode = "54321", City = "City2", Country = "Country2" }
         
        );

    }
}

public class SalaryInfo
{
}